﻿public class Task
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string Status { get; set; }
    public DateTime? DueDate { get; set; }
    public int? AssignedTo { get; set; }
    public User AssignedUser { get; set; }
    public ICollection<Attachment> Attachments { get; set; }
    public ICollection<Note> Notes { get; set; }
}
